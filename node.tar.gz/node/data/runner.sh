#!/bin/sh

# Fetch from environment variables with fallback to default values
CHAIN_ID=97453
NODE_PORT=${NODE_PORT:-30301}
HTTP_PORT=${HTTP_PORT:-8545}
WEBSOCKET_PORT=${WEBSOCKET_PORT:-8546}

# Cd to the directory of this script
printf "Using configuration:\n"
printf "Chain ID: %s\n" "$CHAIN_ID"
printf "Node Port: %s\n" "$NODE_PORT"
printf "HTTP Port: %s\n" "$HTTP_PORT"
printf "WebSocket Port: %s\n" "$WEBSOCKET_PORT"

geth --datadir . --networkid $CHAIN_ID --port $NODE_PORT \
    --syncmode full \
    --discovery.port 30303 \
    --config ./config.toml \
    --http \
    --http.addr "0.0.0.0" \
    --http.port $HTTP_PORT \
    --http.api "eth,net,web3,debug" \
    --http.corsdomain "*" \
    --http.vhosts "*" \
    --ws \
    --ws.addr "0.0.0.0" \
    --ws.port $WEBSOCKET_PORT \
    --ws.api "eth,net,web3,debug" \
    --ws.origins "*"
    
    
    